package br.com.mv.gh.desafioghdev1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioGhDev1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
