package br.com.mv.gh.desafioghdev1.repository;

import br.com.mv.gh.desafioghdev1.model.States;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StatesRepository extends JpaRepository<States, Long> {

}
