package br.com.mv.gh.desafioghdev1.dto;

import java.util.List;

public class StatesFormatDTO {

    private List<StatesReciveDTO> states;

    public StatesFormatDTO() {
    }

    public StatesFormatDTO(List<StatesReciveDTO> value) {
        this.states = value;
    }

    public List<StatesReciveDTO> getStates() {
        return states;
    }

    public void setStates(List<StatesReciveDTO> states) {
        this.states = states;
    }
}
