package br.com.mv.gh.desafioghdev1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesafioGhDev1Application {

	public static void main(String[] args) {
		SpringApplication.run(DesafioGhDev1Application.class, args);
	}

}
