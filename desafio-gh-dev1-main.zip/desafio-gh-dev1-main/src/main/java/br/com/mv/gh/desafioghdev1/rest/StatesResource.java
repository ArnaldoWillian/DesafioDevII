package br.com.mv.gh.desafioghdev1.rest;

import br.com.mv.gh.desafioghdev1.model.States;
import br.com.mv.gh.desafioghdev1.service.StatesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value="api/states")
public class StatesResource {

	@Autowired
	private StatesService statesService;

	
	@RequestMapping(value="/list", method=RequestMethod.GET)
	public List<States> list() {
		return statesService.list();
	}

	@RequestMapping(value="/atualizar", method=RequestMethod.GET)
	public void consumir() {
		 statesService.consumirEArmazenarEstados();
	}
	
}
