package br.com.mv.gh.desafioghdev1.service;

import br.com.mv.gh.desafioghdev1.dto.StatesFormatDTO;
import br.com.mv.gh.desafioghdev1.dto.StatesReciveDTO;
import br.com.mv.gh.desafioghdev1.model.States;
import br.com.mv.gh.desafioghdev1.repository.StatesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Service
public class StatesService {

    @Autowired
    private StatesRepository statesRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<States> list() {
        return statesRepository.findAll();
    }

    public void consumirEArmazenarEstados() {

		if(!statesRepository.findAll().isEmpty()) {
			statesRepository.deleteAll();
		}

        String endpoint = "https://www.healthcare.gov/api/states.json";

        RestTemplate restTemplate = new RestTemplate();

        StatesFormatDTO object = restTemplate.getForObject(endpoint, StatesFormatDTO.class);

		List<States> statesToSave = new ArrayList<>();


		for (StatesReciveDTO estado : object.getStates()) {

			if (estado.getLang().equals("en")) {

					States states = new States();
					states.setTitle(estado.getTitle());
					states.setUrl(estado.getUrl());

					statesToSave.add(states);

			}

		}
		if(statesToSave != null) {
			statesRepository.saveAll(statesToSave);
		}

    }

}
