INSERT INTO person (id, name) VALUES (1, 'José');
INSERT INTO person (id, name) VALUES (2, 'Maria');
INSERT INTO person (id, name) VALUES (3, 'João');
INSERT INTO person (id, name) VALUES (4, 'Felipe');
INSERT INTO person (id, name) VALUES (5, 'Ana');

